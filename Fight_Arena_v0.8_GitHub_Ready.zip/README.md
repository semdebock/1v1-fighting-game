# Fight Arena v0.8

Standalone browser build of the Fight Arena prototype.

## What's included
- Rookie playable character
- El Primo playable character, purchasable for 1,000 coins
- Character Gallery
- Coins, gems, XP and player level
- Local save data via browser localStorage
- Campaign level selection
- Level 1: Nightfang (Easy)
- Level 2: Ultron (Normal) using the original robot design created for this project
- Level 2 unlocks after defeating Nightfang
- Ultron has 125 HP, 110% damage and an Energy Pulse ranged attack
- Touch controls for iPad / mobile
- Fight rewards and result screen

## Test locally
Open `index.html` in a browser. For the most reliable iPad testing, host the folder with GitHub Pages.

## GitHub Pages
1. Create a new GitHub repository, e.g. `fight-arena`.
2. Upload every file and folder from this project.
3. Open repository Settings -> Pages.
4. Under Build and deployment, choose `Deploy from a branch`.
5. Select branch `main` and folder `/ (root)`.
6. Save.
7. GitHub will provide a URL similar to `https://YOURNAME.github.io/fight-arena/`.

## Project structure
- `index.html` — app screens and controls
- `css/styles.css` — visual design and character sprites
- `js/characters.js` — playable fighter definitions
- `js/enemies.js` — campaign opponents and levels
- `js/save.js` — local progression save
- `js/game.js` — combat, UI and campaign logic

This split structure is intentional: future updates can change one system without rewriting the whole game.
