
(() => {
  const $ = id => document.getElementById(id);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const state = loadSave();

  Object.keys(Characters).forEach(name => {
    Characters[name].owned = !!state.ownedCharacters[name];
  });

  let previewCharacter = state.selectedCharacter;
  let selectedCampaignLevel = 1;
  let fight = null;
  let rafId = null;
  let secondTimer = null;

  function show(screen) {
    document.querySelectorAll(".screen").forEach(el => el.classList.remove("active"));
    $("screen-" + screen).classList.add("active");
  }

  function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.remove("hidden");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => t.classList.add("hidden"), 1400);
  }

  function persist() {
    state.ownedCharacters = {};
    Object.keys(Characters).forEach(name => state.ownedCharacters[name] = Characters[name].owned);
    saveGame(state);
  }

  function updateHud() {
    $("coins").textContent = state.coins.toLocaleString();
    $("gems").textContent = state.gems;
    $("playerLevel").textContent = state.playerLevel;
    $("xpText").textContent = `${state.xp} / ${state.xpNeed}`;
    $("xpBar").style.width = `${state.xp / state.xpNeed * 100}%`;
  }

  function addXp(amount) {
    state.xp += amount;
    let leveled = false;
    while (state.xp >= state.xpNeed) {
      state.xp -= state.xpNeed;
      state.playerLevel++;
      state.xpNeed = Math.round(state.xpNeed * 1.25);
      state.coins += 150;
      state.gems += 5;
      leveled = true;
    }
    persist();
    updateHud();
    if (leveled) toast("LEVEL UP! +150 🪙 +5 💎");
  }

  function renderHome() {
    const c = Characters[state.selectedCharacter];
    $("homeFighter").innerHTML = characterMarkup(c.name, "");
    const el = $("homeFighter").firstElementChild;
    el.style.position = "relative";
    el.style.transform = c.name === "El Primo" ? "scale(1.25)" : "scale(1.35)";
    el.style.marginBottom = "55px";
    $("homeFighterName").textContent = c.name.toUpperCase();
  }

  function renderGallery() {
    const grid = $("characterGrid");
    grid.innerHTML = "";
    Object.values(Characters).forEach(c => {
      const card = document.createElement("button");
      card.className = `char-card ${previewCharacter === c.name ? "selected" : ""} ${!c.owned ? "locked" : ""}`;
      const markup = characterMarkup(c.name, "");
      card.innerHTML = `<div class="thumb">${markup}</div><strong>${c.name.toUpperCase()}</strong><small>${c.owned ? (state.selectedCharacter === c.name ? "✓ SELECTED" : "OWNED") : "🪙 " + c.price}</small>`;
      const sprite = card.querySelector(".rookie,.primo");
      sprite.style.position = "relative";
      sprite.style.transform = c.name === "El Primo" ? "scale(.56)" : "scale(.62)";
      card.addEventListener("click", () => {
        previewCharacter = c.name;
        renderGallery();
        renderCharacterInfo();
      });
      grid.appendChild(card);
    });
  }

  function renderCharacterInfo() {
    const c = Characters[previewCharacter];
    $("charRarity").textContent = c.rarity.toUpperCase();
    $("charName").textContent = c.name.toUpperCase();
    $("charStyle").textContent = c.style;
    $("statPower").textContent = c.power;
    $("statSpeed").textContent = c.speed;
    $("statHealth").textContent = c.health;
    $("statSpecial").textContent = c.special;
    $("charBio").textContent = c.bio;
    if (!c.owned) {
      $("btnCharAction").textContent = `BUY • ${c.price} 🪙`;
      $("btnCharAction").disabled = false;
      $("priceLine").textContent = "Permanent character unlock.";
    } else {
      $("btnCharAction").textContent = state.selectedCharacter === c.name ? "SELECTED" : "SELECT";
      $("btnCharAction").disabled = state.selectedCharacter === c.name;
      $("priceLine").textContent = "Owned";
    }
  }

  function renderLevels() {
    const grid = $("levelGrid");
    grid.innerHTML = "";
    CampaignLevels.forEach(l => {
      const unlocked = l.level <= state.maxUnlockedCampaignLevel;
      const card = document.createElement("button");
      card.className = `level-card ${selectedCampaignLevel === l.level ? "selected" : ""} ${!unlocked ? "locked" : ""}`;
      card.innerHTML = `<div class="eyebrow">LEVEL ${l.level}</div><h3>${l.enemy.toUpperCase()}</h3><div>${l.difficulty}</div><small>${unlocked ? `🪙 ${l.coins} • XP ${l.xp}` : "🔒 LOCKED"}</small>`;
      card.addEventListener("click", () => {
        if (!unlocked) return toast(`Beat Level ${l.level - 1} first`);
        selectedCampaignLevel = l.level;
        renderLevels();
        renderLevelPreview();
      });
      grid.appendChild(card);
    });
  }

  function renderLevelPreview() {
    const l = CampaignLevels[selectedCampaignLevel - 1];
    $("levelDifficulty").textContent = l.difficulty.toUpperCase();
    $("levelTitle").textContent = `LEVEL ${l.level} — ${l.enemy.toUpperCase()}`;
    $("levelDescription").textContent = l.description;
    $("levelHp").textContent = l.hp;
    $("levelDamage").textContent = Math.round(l.damageMultiplier * 100) + "%";
    $("levelAi").textContent = l.ai.toUpperCase();
    $("levelReward").textContent = `${l.coins} 🪙 / ${l.xp} XP`;
    $("enemyPreview").innerHTML = enemyMarkup(l.enemy, "");
    const sprite = $("enemyPreview").firstElementChild;
    sprite.style.position = "relative";
    sprite.style.transform = l.enemy === "Ultron" ? "scale(1.08)" : "scale(1.15)";
    sprite.style.marginBottom = "25px";
  }

  function createPlayerSprite() {
    $("playerSprite").innerHTML = characterMarkup(state.selectedCharacter, "battle-player");
    $("playerSprite").firstElementChild.id = "playerBattle";
  }

  function createEnemySprite() {
    $("enemySprite").innerHTML = enemyMarkup(fight.level.enemy, "battle-enemy");
    $("enemySprite").firstElementChild.id = "enemyBattle";
  }

  function drawFight() {
    if (!fight) return;
    const p = $("playerBattle"), e = $("enemyBattle");
    p.style.left = fight.px + "%";
    e.style.left = fight.ex + "%";
    p.style.bottom = `calc(14% + ${fight.jumpY}px)`;
    $("playerHpText").textContent = Math.ceil(fight.playerHp);
    $("enemyHpText").textContent = Math.ceil(fight.enemyHp);
    $("playerHpBar").style.width = `${fight.playerHp / fight.playerMaxHp * 100}%`;
    $("enemyHpBar").style.width = `${fight.enemyHp / fight.enemyMaxHp * 100}%`;
    $("specialText").textContent = Math.floor(fight.special) + "%";
    $("specialBar").style.width = fight.special + "%";
    $("btnSpecial").disabled = fight.special < 100 || fight.over;
    $("timer").textContent = fight.time;
  }

  function impact() {
    const i = $("impact");
    i.style.left = ((fight.px + fight.ex) / 2 + 3) + "%";
    i.style.top = "48%";
    i.classList.remove("hidden");
    i.style.animation = "none";
    void i.offsetWidth;
    i.style.animation = "impact .22s forwards";
    setTimeout(() => i.classList.add("hidden"), 230);
  }

  function hitEnemy(damage, push) {
    if (!fight || fight.over) return;
    fight.enemyHp = clamp(fight.enemyHp - damage, 0, fight.enemyMaxHp);
    fight.special = clamp(fight.special + damage * 1.3, 0, 100);
    fight.combo++;
    fight.comboWindow = .7;
    if (fight.combo >= 2) {
      $("comboText").textContent = `${fight.combo} HIT COMBO`;
      $("comboText").classList.remove("hidden");
    }
    fight.ex = clamp(fight.ex + push, 8, 92);
    $("enemyBattle").classList.add("hurt");
    setTimeout(() => $("enemyBattle")?.classList.remove("hurt"), 150);
    impact();
    if (fight.enemyHp <= 0) endFight(true);
    drawFight();
  }

  function playerAttack(type) {
    if (!fight || fight.over || fight.busy) return;
    fight.busy = true;
    const c = Characters[state.selectedCharacter];
    const p = $("playerBattle");
    p.classList.add(type === "kick" ? "kicking" : "punching");
    setTimeout(() => p?.classList.remove("kicking", "punching"), 260);
    if (Math.abs(fight.ex - fight.px) < 15) {
      setTimeout(() => hitEnemy(
        type === "kick" ? c.kickDamage : c.punchDamage,
        type === "kick" ? (c.name === "El Primo" ? 4.8 : 3.5) : (c.name === "El Primo" ? 3 : 2)
      ), 75);
    }
    setTimeout(() => { if (fight) fight.busy = false; }, 280);
  }

  function playerSpecial() {
    if (!fight || fight.over || fight.busy || fight.special < 100) return;
    const c = Characters[state.selectedCharacter];
    fight.busy = true;
    fight.special = 0;
    $("playerBattle").classList.add("specialing");
    if (Math.abs(fight.ex - fight.px) < (c.name === "El Primo" ? 25 : 23)) {
      setTimeout(() => hitEnemy(c.specialDamage, c.name === "El Primo" ? 10 : 7), c.name === "El Primo" ? 210 : 120);
    }
    setTimeout(() => {
      $("playerBattle")?.classList.remove("specialing");
      if (fight) fight.busy = false;
    }, 460);
    drawFight();
  }

  function enemyMelee() {
    if (!fight || fight.over || Math.abs(fight.ex - fight.px) >= 14) return;
    const l = fight.level;
    let dmg = Math.round(7 * l.damageMultiplier);
    if (fight.blocking) dmg = Math.max(2, Math.round(dmg * .28));
    fight.playerHp = clamp(fight.playerHp - dmg, 0, fight.playerMaxHp);
    fight.px = clamp(fight.px - (fight.blocking ? .5 : 1.8), 3, 90);
    $("enemyBattle").classList.add("enemy-punch");
    setTimeout(() => $("enemyBattle")?.classList.remove("enemy-punch"), 220);
    $("playerBattle").classList.add("hurt");
    setTimeout(() => $("playerBattle")?.classList.remove("hurt"), 150);
    impact();
    if (fight.playerHp <= 0) endFight(false);
    drawFight();
  }

  function ultronPulse() {
    if (!fight || fight.over || fight.level.enemy !== "Ultron" || fight.pulseActive) return;
    fight.pulseActive = true;
    const proj = $("projectile");
    proj.classList.remove("hidden");
    const start = fight.ex - 1;
    let pos = start;
    proj.style.left = pos + "%";
    proj.style.top = "48%";
    const pulse = setInterval(() => {
      if (!fight || fight.over) {
        clearInterval(pulse); proj.classList.add("hidden"); return;
      }
      pos -= 2.5;
      proj.style.left = pos + "%";
      if (Math.abs(pos - fight.px) < 5) {
        clearInterval(pulse);
        proj.classList.add("hidden");
        const dmg = fight.blocking ? 3 : 11;
        fight.playerHp = clamp(fight.playerHp - dmg, 0, fight.playerMaxHp);
        $("playerBattle").classList.add("hurt");
        setTimeout(() => $("playerBattle")?.classList.remove("hurt"), 150);
        impact();
        fight.pulseActive = false;
        if (fight.playerHp <= 0) endFight(false);
        drawFight();
      } else if (pos < 0) {
        clearInterval(pulse);
        proj.classList.add("hidden");
        fight.pulseActive = false;
      }
    }, 30);
  }

  function endFight(win) {
    if (!fight || fight.over) return;
    fight.over = true;
    fight.move = 0;
    (win ? $("enemyBattle") : $("playerBattle")).classList.add("koed");
    $("koOverlay").textContent = win ? "K.O. • YOU WIN" : `K.O. • ${fight.level.enemy.toUpperCase()} WINS`;
    $("koOverlay").classList.remove("hidden");
    setTimeout(() => showResults(win), 800);
  }

  function showResults(win) {
    const l = fight.level;
    const coins = win ? l.coins : 20;
    const xp = win ? l.xp : 10;
    const gems = win ? l.gems : 0;
    let unlocked = false;

    state.coins += coins;
    state.gems += gems;
    if (win && l.level === state.maxUnlockedCampaignLevel && l.level < CampaignLevels.length) {
      state.maxUnlockedCampaignLevel++;
      unlocked = true;
    }
    addXp(xp);
    persist();
    updateHud();

    $("resultTitle").textContent = win ? "VICTORY" : "DEFEAT";
    $("resultText").textContent = win ? `${l.enemy} Level ${l.level} defeated.` : `${l.enemy} won this round.`;
    $("rewardCoins").textContent = "+" + coins;
    $("rewardXp").textContent = "+" + xp;
    $("rewardGems").textContent = "+" + gems;
    $("unlockPanel").classList.toggle("hidden", !unlocked);
    if (unlocked) {
      const next = CampaignLevels[state.maxUnlockedCampaignLevel - 1];
      $("unlockPanel").textContent = `🔓 LEVEL ${next.level} UNLOCKED — ${next.enemy.toUpperCase()}!`;
    }
    $("btnNext").textContent = win && l.level < CampaignLevels.length && l.level < state.maxUnlockedCampaignLevel ? "NEXT LEVEL" : "REMATCH";
    stopFightLoop();
    show("results");
  }

  function resetFight() {
    const l = CampaignLevels[selectedCampaignLevel - 1];
    const c = Characters[state.selectedCharacter];
    fight = {
      level: l, playerMaxHp: c.health, playerHp: c.health, enemyMaxHp: l.hp, enemyHp: l.hp,
      px: 12, ex: 79, move: 0, blocking: false, over: false, busy: false,
      jumpY: 0, jumpV: 0, special: 0, combo: 0, comboWindow: 0,
      attackCd: l.attackCooldown, pulseCd: 4.5, pulseActive: false, time: 60, last: performance.now()
    };
    createPlayerSprite();
    createEnemySprite();
    $("koOverlay").classList.add("hidden");
    $("comboText").classList.add("hidden");
    $("fightPlayerName").textContent = c.name.toUpperCase();
    $("fighterTag").textContent = c.name.toUpperCase();
    $("fightEnemyName").textContent = l.enemy.toUpperCase();
    $("fightDifficulty").textContent = `${l.difficulty.toUpperCase()} • LEVEL ${l.level}`;
    drawFight();
  }

  function startFight() {
    show("fight");
    resetFight();
    startFightLoop();
  }

  function startFightLoop() {
    stopFightLoop();
    secondTimer = setInterval(() => {
      if (!fight || fight.over) return;
      fight.time--;
      if (fight.time <= 0) {
        fight.time = 0;
        const pPct = fight.playerHp / fight.playerMaxHp;
        const ePct = fight.enemyHp / fight.enemyMaxHp;
        endFight(pPct >= ePct);
      }
      drawFight();
    }, 1000);

    const loop = now => {
      if (!fight) return;
      const dt = Math.min((now - fight.last) / 1000, .035);
      fight.last = now;
      if (!fight.over && $("screen-fight").classList.contains("active")) {
        const c = Characters[state.selectedCharacter];
        fight.px = clamp(fight.px + fight.move * c.moveSpeed * dt, 3, 90);
        if (fight.px > fight.ex - 7) fight.px = fight.ex - 7;

        const gap = fight.ex - fight.px;
        if (gap > 16) fight.ex -= fight.level.moveSpeed * dt;
        else if (gap < 9) fight.ex += fight.level.moveSpeed * .7 * dt;
        fight.ex = clamp(fight.ex, fight.px + 7, 92);

        fight.attackCd -= dt;
        if (fight.attackCd <= 0 && gap < 14) {
          enemyMelee();
          fight.attackCd = fight.level.attackCooldown * (.9 + Math.random() * .45);
        }

        if (fight.level.enemy === "Ultron") {
          fight.pulseCd -= dt;
          if (fight.pulseCd <= 0 && gap >= 13) {
            ultronPulse();
            fight.pulseCd = 6 + Math.random() * 4;
          }
        }

        if (fight.jumpY > 0 || fight.jumpV > 0) {
          fight.jumpV -= 900 * dt;
          fight.jumpY += fight.jumpV * dt;
          if (fight.jumpY <= 0) { fight.jumpY = 0; fight.jumpV = 0; }
        }

        if (fight.comboWindow > 0) {
          fight.comboWindow -= dt;
          if (fight.comboWindow <= 0) { fight.combo = 0; $("comboText").classList.add("hidden"); }
        }
        drawFight();
      }
      rafId = requestAnimationFrame(loop);
    };
    rafId = requestAnimationFrame(loop);
  }

  function stopFightLoop() {
    if (rafId) cancelAnimationFrame(rafId);
    if (secondTimer) clearInterval(secondTimer);
    rafId = null; secondTimer = null;
  }

  // UI
  $("btnGallery").addEventListener("click", () => {
    previewCharacter = state.selectedCharacter;
    renderGallery(); renderCharacterInfo(); show("gallery");
  });
  $("btnGalleryBack").addEventListener("click", () => { renderHome(); show("home"); });
  $("btnPlay").addEventListener("click", () => { selectedCampaignLevel = Math.min(state.maxUnlockedCampaignLevel, CampaignLevels.length); renderLevels(); renderLevelPreview(); show("levels"); });
  $("btnLevelsBack").addEventListener("click", () => show("home"));
  $("btnStartFight").addEventListener("click", startFight);
  $("btnQuitFight").addEventListener("click", () => { stopFightLoop(); fight = null; show("home"); });
  $("btnMainMenu").addEventListener("click", () => { renderHome(); show("home"); });
  $("btnNext").addEventListener("click", () => {
    if (fight && fight.level.level < state.maxUnlockedCampaignLevel && fight.level.level < CampaignLevels.length) selectedCampaignLevel = fight.level.level + 1;
    startFight();
  });

  $("btnDaily").addEventListener("click", () => {
    if (state.dailyClaimed) return toast("Daily reward already claimed");
    state.dailyClaimed = true; state.coins += 250; persist(); updateHud(); toast("+250 coins 🪙");
  });
  $("btnMissions").addEventListener("click", () => toast("Missions coming soon"));
  $("btnShop").addEventListener("click", () => toast("Shop coming soon"));

  $("btnCharAction").addEventListener("click", () => {
    const c = Characters[previewCharacter];
    if (!c.owned) {
      if (state.coins < c.price) return toast("Not enough coins");
      state.coins -= c.price; c.owned = true; state.ownedCharacters[c.name] = true;
      toast(`${c.name.toUpperCase()} UNLOCKED!`);
    }
    state.selectedCharacter = c.name;
    persist(); updateHud(); renderGallery(); renderCharacterInfo(); renderHome();
  });

  $("btnPunch").addEventListener("pointerdown", () => playerAttack("punch"));
  $("btnKick").addEventListener("pointerdown", () => playerAttack("kick"));
  $("btnSpecial").addEventListener("pointerdown", playerSpecial);
  $("btnJump").addEventListener("pointerdown", () => {
    if (!fight || fight.over || fight.jumpY !== 0) return;
    fight.jumpV = Characters[state.selectedCharacter].jumpPower;
  });

  const blockBtn = $("btnBlock");
  blockBtn.addEventListener("pointerdown", () => {
    if (!fight || fight.over) return;
    fight.blocking = true; $("playerBattle").classList.add("blocking");
  });
  ["pointerup","pointerleave","pointercancel"].forEach(evt => blockBtn.addEventListener(evt, () => {
    if (!fight) return;
    fight.blocking = false; $("playerBattle")?.classList.remove("blocking");
  }));

  const stick = $("stick"), knob = $("knob");
  let stickId = null;
  function stickMove(e) {
    if (!fight) return;
    const r = stick.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2);
    const max = r.width * .28;
    const n = clamp(dx / max, -1, 1);
    fight.move = Math.abs(n) > .15 ? n : 0; // left really is left; right really is right
    knob.style.transform = `translateX(${n * max}px)`;
  }
  stick.addEventListener("pointerdown", e => {
    stickId = e.pointerId; stick.setPointerCapture(e.pointerId); stickMove(e);
  });
  stick.addEventListener("pointermove", e => { if (e.pointerId === stickId) stickMove(e); });
  function releaseStick(e) {
    if (e.pointerId !== stickId) return;
    stickId = null; if (fight) fight.move = 0; knob.style.transform = "translateX(0)";
  }
  stick.addEventListener("pointerup", releaseStick);
  stick.addEventListener("pointercancel", releaseStick);

  updateHud(); renderHome(); renderGallery(); renderCharacterInfo();
})();
