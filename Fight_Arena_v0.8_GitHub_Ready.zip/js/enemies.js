
const CampaignLevels = [
  {
    level: 1,
    enemy: "Nightfang",
    difficulty: "Easy",
    hp: 100,
    damageMultiplier: 1.0,
    moveSpeed: 9,
    attackCooldown: 0.95,
    ai: "Low",
    coins: 100,
    xp: 25,
    gems: 0,
    description: "Fast but predictable. Nightfang is the first test for every fighter.",
    special: null
  },
  {
    level: 2,
    enemy: "Ultron",
    difficulty: "Normal",
    hp: 125,
    damageMultiplier: 1.10,
    moveSpeed: 8.2,
    attackCooldown: 0.78,
    ai: "Normal",
    coins: 175,
    xp: 40,
    gems: 0,
    description: "A heavily armored rogue combat android with smarter positioning and a ranged Energy Pulse.",
    special: "Energy Pulse"
  }
];

function nightfangMarkup(extraClass="") {
  return `<div class="nightfang ${extraClass}"><div class="nfHood"></div><div class="nfFace"><i></i><i></i></div><div class="nfScarf"></div><div class="nfTorso"></div><div class="nfArm nla"><span></span></div><div class="nfArm nra"><span></span></div><div class="nfLeg nll"><span></span></div><div class="nfLeg nrl"><span></span></div></div>`;
}
function ultronMarkup(extraClass="") {
  return `<div class="ultron ${extraClass}"><div class="uHead"></div><div class="uCore"></div><div class="uTorso"></div><div class="uShoulder usl"></div><div class="uShoulder usr"></div><div class="uArm ual"><span></span></div><div class="uArm uar"><span></span></div><div class="uLeg ull"><span></span></div><div class="uLeg url"><span></span></div></div>`;
}
function enemyMarkup(name, extraClass="") {
  return name === "Ultron" ? ultronMarkup(extraClass) : nightfangMarkup(extraClass);
}
