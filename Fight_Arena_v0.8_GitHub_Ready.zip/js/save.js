
const SAVE_KEY = "fight-arena-v08";
const defaultSave = {
  coins: 1250,
  gems: 50,
  playerLevel: 1,
  xp: 0,
  xpNeed: 100,
  selectedCharacter: "Rookie",
  maxUnlockedCampaignLevel: 1,
  dailyClaimed: false,
  ownedCharacters: { "Rookie": true, "El Primo": false }
};

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return structuredClone(defaultSave);
    return { ...structuredClone(defaultSave), ...JSON.parse(raw) };
  } catch {
    return structuredClone(defaultSave);
  }
}
function saveGame(state) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(state)); } catch {}
}
function resetSave() {
  try { localStorage.removeItem(SAVE_KEY); } catch {}
}
