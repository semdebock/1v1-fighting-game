
const Characters = {
  Rookie: {
    name: "Rookie", rarity: "Common", style: "Balanced", power: 55, speed: 60,
    health: 100, special: 50, price: 0, owned: true,
    bio: "A determined beginner who never gives up.",
    moveSpeed: 29, punchDamage: 8, kickDamage: 13, specialDamage: 25, jumpPower: 390
  },
  "El Primo": {
    name: "El Primo", rarity: "Rare", style: "Tank / Close Range", power: 82, speed: 42,
    health: 140, special: 62, price: 1000, owned: false,
    bio: "A heavyweight luchador built to absorb damage and punish opponents up close.",
    moveSpeed: 23, punchDamage: 11, kickDamage: 16, specialDamage: 34, jumpPower: 350
  }
};

function rookieMarkup(extraClass="") {
  return `<div class="rookie ${extraClass}"><div class="hair"></div><div class="face"><i></i><i></i></div><div class="hood"></div><div class="torso"></div><div class="belt"></div><div class="arm la"><span></span></div><div class="arm ra"><span></span></div><div class="leg ll"><span></span></div><div class="leg rl"><span></span></div></div>`;
}
function primoMarkup(extraClass="") {
  return `<div class="primo ${extraClass}"><div class="mask"></div><div class="jaw"></div><div class="chest"></div><div class="beltP"></div><div class="pArm pla"><span></span></div><div class="pArm pra"><span></span></div><div class="pLeg pll"><span></span></div><div class="pLeg prl"><span></span></div></div>`;
}
function characterMarkup(name, extraClass="") {
  return name === "El Primo" ? primoMarkup(extraClass) : rookieMarkup(extraClass);
}
